﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace unitestyStachCerveny
{
    internal class Npc : HerniPostava
    {
        bool sila = false;
        string prace = string.Empty;

        public Npc(bool sila, string prace,string jmeno) : base(jmeno)
        {
            this.sila = sila;
            this.prace = prace;
        }

        public Npc(string prace, string jmeno) : base(jmeno)
        {
            
            this.prace = prace;
        }

        public override int ZmenaPozice(int x, int y)
        {
            return base.ZmenaPozice(2,3);
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
