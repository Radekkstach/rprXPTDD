﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace unitestyStachCerveny
{
    public class Hrac : HerniPostava
    {
        public int oblicej = 0;
        public int vlasy = 0;
        public int barvavlasu = 0;
        public int xp = 0;

        public Hrac(int oblicej, int vlasy, int barvavlasu, string specializace, string jmeno) : base(jmeno)
        {
            this.oblicej = oblicej;
            this.vlasy = vlasy;
            this.barvavlasu = barvavlasu;
            this.specializace = specializace;
        }
        public string specializace = string.Empty;
        //string Specializace
        //{
        //    get; set;
        //}

        void Xp()
        {
            
        }

        public int PridejXP(int x)
        {
            return xp += x;
        }

        public override string ToString()
        {
            return oblicej + " jj";
        }
        
    }
}
